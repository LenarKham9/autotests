def bubble_sort(numbers):
    n = len(numbers)
    # Проходим по списку n-1 раз
    for i in range(n-1):
        # Каждый проход уменьшает количество сравнений
        for j in range(n-i-1):
            # Если текущий элемент больше следующего - меняем местами
            if numbers[j] > numbers[j+1]:
                numbers[j], numbers[j+1] = numbers[j+1], numbers[j]
    return numbers

# Запрашиваем ввод от пользователя
input_str = input("Введите числа через запятую: ")

# Преобразуем строку в список чисел
try:
    numbers = [float(num.strip()) for num in input_str.split(',')]
except ValueError:
    print("Ошибка: введите только числа, разделенные запятыми!")
    exit()

# Сортируем список
sorted_numbers = bubble_sort(numbers.copy())  # Используем copy(), чтобы не изменять исходный список

# Выводим результат
print("\nИсходный список:", numbers)
print("Отсортированный список:", sorted_numbers)