from datetime import datetime  # Импортируем модуль для работы с датой

def calculate_age(birth_year):
    current_year = datetime.now().year  # Получаем текущий год
    return current_year - birth_year  # Возраст = текущий год - год рождения

def get_age_message(age):
    if age < 18:
        return "Вы еще молоды, учеба — ваш путь!"
    elif 18 <= age <= 65:
        return "Отличный возраст для карьерного роста!"
    else:
        return "Пора наслаждаться заслуженным отдыхом!"

# Взаимодействие с пользователем
birth_year = int(input("Введите ваш год рождения: "))
age = calculate_age(birth_year)
message = get_age_message(age)

print(f"Ваш возраст: {age} лет.")

print(message)