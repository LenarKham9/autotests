greet_user=input("Введите ваше Имя:")
print(f"Привет {greet_user}! Добро пожаловать в мир Пайтон")

def calculate_sum(a,b):
    return a+b

num1=float(input("Введите первое число: "))
num2=float(input("Введите второе число: "))
sum_result=calculate_sum(num1,num2)

print(f"Сумма числе {num1} и {num2} равна: {sum_result}")