def calculator():
    # Ввод данных
    num1 = float(input("Введите первое число: "))
    num2 = float(input("Введите второе число: "))
    operation = input("Выберите операцию (+, -, *, /): ")

    # Вложенные функции для операций
    def add():
        return num1 + num2

    def subtract():
        return num1 - num2

    def multiply():
        return num1 * num2

    def divide():
        if num2 != 0:
            return num1 / num2
        else:
            return "Ошибка: деление на ноль!"

    # Выбор и выполнение операции
    if operation == '+':
        result = add()
    elif operation == '-':
        result = subtract()
    elif operation == '*':
        result = multiply()
    elif operation == '/':
        result = divide()
    else:
        result = "Неверная операция"

    # Вывод результата
    print(f"Результат: {result}")

# Запуск калькулятора
calculator()