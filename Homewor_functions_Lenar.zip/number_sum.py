


n = int(input("Введите число n: "))

# Выводим числа от 1 до n через пробел
print("Числа от 1 до n:", end=" ")
i = 1
while i <= n:
    print(i, end=" ")
    i += 1

# Вычисляем сумму чисел от 1 до n
sum_numbers = 0
i = 1
while i <= n:
    sum_numbers += i
    i += 1

print("\nСумма чисел от 1 до n:", sum_numbers)